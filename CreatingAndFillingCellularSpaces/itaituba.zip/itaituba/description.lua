version = "0.1"
license = "LGPL-3"
package = "itaituba"
title = ""
url = "http://www.terrame.org"
authors = "INPE"
contact = "pedro.andrade@inpe.br"
content = [[This package is a small example about how to automatically document cellular spaces.]]
